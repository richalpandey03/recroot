import React, { useState } from 'react';
import axios from 'axios';
import CreateEditBlog from '../../Blog/BlogCreate';
import "./index.css"

function UserRegistration() {
  const [userRegistred, setUserRegistered] = useState(false)
  const [userData, setUserData] = useState({
    username: '',
    email: '',
    password: '',
    userimage: ''
  });

  const handleChange = (e) => {
    const { name, value, files } = e.target;
  if (name === 'userimage') {
    setUserData({ ...userData, [name]: files[0] });
  } else {
    setUserData({ ...userData, [name]: value });
  }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('username', userData.username);
    formData.append('email', userData.email);
    formData.append('password', userData.password);
    formData.append('userimage', userData.userimage); // Append the file data
    try {
      const response = await axios.post('http://localhost:5000/user/createuser', formData, {
        headers: {
          'Content-Type': 'multipart/form-data', // Set content type for FormData
        },
      });
      localStorage.setItem('userEmail', userData.email);
      e.target.reset(); 
      setUserData({
        username: '',
        email: '',
        password: '',
        userimage: ''
      });
      setUserRegistered(true)
    } catch (error) {
      alert(err)
      console.error('Error:', error);
    }
  };

  return (
    <div>
      {!userRegistred ? 
      <div className="registration-parent">
          <div className='form-div'>
              <h2>User Registration</h2>
              <form onSubmit={handleSubmit}>
                  <div>
                  <input type="text" name="username" value={userData.username} onChange={handleChange}  placeholder="Username" className='input-text'/></div>
                  <div><input type="email" name="email" value={userData.email} onChange={handleChange} placeholder="Email" className='input-text'/></div>
                  <div><input type="password" name="password" value={userData.password} onChange={handleChange} placeholder="Password" className='input-text'/></div>
                  <div className='profile-div'>
                      <div className='span-div'><span className='profile-pic-span'>Profile Picture</span></div>
                  <input type="file" accept="image/*" name="userimage" onChange={handleChange} /> </div>
                  <button type="submit" className='registration-button'>Submit</button>
              </form>
          </div>
      </div>
    : <CreateEditBlog/> }
    </div>
  );
}

export default UserRegistration;
