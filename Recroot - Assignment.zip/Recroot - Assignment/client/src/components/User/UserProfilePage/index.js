import React, { useEffect, useState } from 'react';
import userIcon from "../../Blog/BlogList/user.webp"
import homeIcon from "../../Blog/BlogList/home1.png"
import axios from 'axios';
import "./index.css"

function UserProfile() {
  const [userDataState, setUserData] = useState({})
  useEffect(()=>{
    async function fetchData(){
      const userEmail = localStorage.getItem('userEmail');
      if(userEmail){
        try{
            const requestBody = {
                email : userEmail
            }
            const getUser = await axios.post('http://localhost:5000/user/getuser', requestBody, {
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            if(getUser.data.data.length > 0){
              setUserData(getUser.data.data[0])
            }
        }catch(err){
            alert(err)
            console.log("Error getting User",err)
        }
      } 
    }
    fetchData()
  },[])

  return (
    <div>
      <div className='title-div'>
          <div className='user-profile-title'>
            <img src={userIcon} className="user-image-icon"/>
            <span>User Profile</span>
          </div>
          <div>
            <img src={homeIcon} className="home-image-icon" onClick={()=>{
              window.location.href="/blogs"
            }}/>
          </div>
      </div>
      <div className='details-parent-div'>
        <div className='details-div'>
          <div className='username-label'>
              <span>Username:</span>
          </div>
          <div className='username'>
              <span>{userDataState.username}</span>
          </div>
          <div>
            <span>Email: </span>
          </div>
          <div className='username'>
            <span>{userDataState.email}</span>
          </div>
          </div>
      </div>
    </div>
  );
}

export default UserProfile;
