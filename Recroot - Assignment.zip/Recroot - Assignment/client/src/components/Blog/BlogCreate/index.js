import React, { useState } from 'react';
import axios from 'axios';
import "./index.css"


export default function CreateEditBlog(editBlogData) {
  const [blogData, setBlogData] = useState({
    blogHeading: editBlogData ? editBlogData?.props?.blogData?.blogHeading : '',
    blogBody: editBlogData ? editBlogData?.props?.blogData?.blogBody : '',
    author: editBlogData ? editBlogData?.props?.blogData?.author : '',
    date: editBlogData ? editBlogData?.props?.blogData?.date : '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBlogData({ ...blogData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/blog/createBlog', blogData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      e.target.reset(); 
      setBlogData({
        blogHeading: '',
        blogBody: '',
        author: '',
        date: ''
      });
      window.location.href = "/blogs"
    } catch (error) {
      alert("Something went wrong please try again")
      console.error('Error:', error);
    }
  };

  const edithandleSubmit = async (e) => {
    e.preventDefault();
    const blogDataEdit = blogData;
    blogDataEdit.blogId = editBlogData?.props?.blogId
    try {
      const response = await axios.post('http://localhost:5000/blog/updateBlog', blogData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      e.target.reset(); 
      setBlogData({
        blogHeading: '',
        blogBody: '',
        author: '',
        date: ''
      });
      window.location.href = "/blogs"
    } catch (error) {
      alert("Something went wrong please try again")
      console.error('Error:', error);
    }
  };

  return (
    <div className='form-parent-div'>
      <div className='create-new-blog-parent'>
        <span className='create-new-blog'>{editBlogData?.props?.blogId ? "Edit Blog" : "Create New Blog Post" }</span>
      </div>
      <div className='form-section'>
        <div className='left-div'></div>
        <div className='form-div-blog'>      
          <form onSubmit={editBlogData?.props?.blogId ? edithandleSubmit : handleSubmit}>
            <div>
              <span>Blog Heading</span>
              <input type="text" name="blogHeading" value={blogData.blogHeading} onChange={handleChange} className='input-text-blog'/>
            </div>
            <div><span>Blog Body</span>
              <textarea name="blogBody" value={blogData.blogBody} onChange={handleChange} className='input-text-blog'/>
            </div>
            <div><span>Author</span>
              <input type="text" name="author" value={blogData.author} onChange={handleChange} className='input-text-blog'/>
            </div>
            <div><span>Published Date</span>
              <input type="date" name="date" value={blogData.date} onChange={handleChange} className='input-text-blog'/>
            </div>
            <button type="submit" className='registration-button-blog'>Submit</button>
          </form>
        </div>
        <div className='right-div'></div>
      </div>

    </div>
  );
}
