import React, { useEffect, useState } from "react"
import CreateEditBlog from "../BlogCreate";
import "./index.css"
import axios from 'axios';
import img from "../BlogList/writeicon.png"

export default function SelectedBlog(){
    const params = new URLSearchParams(window.location.search);
    const [blogData, setBlogData] = useState([])
    const [editBlogState, setEditBlog] = useState(false)
    const id = params.get('blogId')
    const [blogId, setBlogId] = useState(id)
    useEffect(()=>{
       fetch(`http://localhost:5000/blog/getBlog?blogId=${params.get('blogId')}`)
       .then((data) => data.json())
       .then((data)=>{
            setBlogData(data[0])
       })
       .catch((err)=>{
        console.log("Error occured in getting blog",err)
       })
    },[])

    const editBlog = async() => {
        const userEmail = localStorage.getItem('userEmail');
        if(userEmail){
            try{
                const requestBody = {
                    email : userEmail
                }
                const getUser = await axios.post('http://localhost:5000/user/getuser', requestBody, {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                if(getUser.data.data.length > 0){
                    setEditBlog(true)
                }
            }catch(err){
                alert("Something went wrong please try again")
                console.log("Error getting User",err)
            }
        }
    }
    return(
        <div>
            {!editBlogState ? 
            <div>
            <div className="blog-heading-div">
                <div className="heading-div">
                    <span>{blogData.blogHeading}</span>
                </div>
                <div className="blog-auth-date">
                    <div>
                        <div>
                            <span>Author : {blogData.author}</span>
                        </div>
                        <div>
                            <span>Published on : {blogData.date}</span>
                        </div>
                    </div>
                    <div>
                        <img src={img} alt="image" className="edit-image" onClick={editBlog}/>
                    </div>
                </div>
            </div>
            <div className="blog-body-div"><span>{blogData.blogBody}</span></div>
            </div>
            : <CreateEditBlog props={{blogData, blogId} }/> }
        </div>
    )
}