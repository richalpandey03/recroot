import React, { useEffect, useState } from "react"
import axios from 'axios';
import CreateEditBlog from "../BlogCreate";
import UserRegistration from "../../User/UserRegistration";
import UserProfile from "../../User/UserProfilePage";
import "./index.css"
import img from "./writeicon.png"
import userIcon from "./user.webp"

export default function List(){
    const [blogList, setBlogList] = useState([])
    const [createBlog, setCreateBlog] = useState(false)
    const [createUser, setCreateUser] = useState(false)
    const [viewProfile, setUserProfile] = useState(false)
    useEffect(()=>{
       fetch('http://localhost:5000/blog/allBlogs')
       .then((data) => data.json())
       .then((data)=>{
            setBlogList(data)
       })
       .catch((err)=>{
            console.log("Error getting all blogs",err)
       })
    },[])

    const handleWrite = async() => {
        const userEmail = localStorage.getItem('userEmail');
        console.log(userEmail)
        if(userEmail){
            try{
                const requestBody = {
                    email : userEmail
                }
                const getUser = await axios.post('http://localhost:5000/user/getuser', requestBody, {
                    headers: {
                        'Content-Type': 'application/json'
                      }
                })
                if(getUser.data.data.length > 0){
                    setCreateBlog(true)
                }else{
                    setCreateBlog(true)
                    setCreateUser(true);
                }
            }catch(err){
                alert("Something went wrong please try again")
                console.log("Error getting user",err)
            }
        }else{
            setCreateBlog(true)
            setCreateUser(true);
        }  
    }

    const handleUser = () =>{
        setCreateBlog(true)
        setUserProfile(true)
    }
    return(
        <div>
            {!createBlog ? 
            <div className="list-parent-div">
                <div className="list-parent">
                    <h1 className="list-title">Blogs</h1>
                    <div className="img-parent">
                        <img src={img} alt="image" className="write-img" onClick={handleWrite}/>
                        <img src={userIcon} alt="image" className="write-img" onClick={handleUser}/>
                    </div>
                </div>
                <div>
                {blogList.map(blog =>{
                    return(<li key={blog.blogId}>
                        <a href={`blog?blogId=${blog.blogId}`}>{blog.blogHeading}</a></li>)
                })}
                </div>
                
            </div>
             : viewProfile ? <UserProfile/> : createUser ? <UserRegistration/>  : <CreateEditBlog/> }
        </div>
    )
}