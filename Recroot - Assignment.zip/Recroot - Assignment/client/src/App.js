import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import List from "./components/Blog/BlogList";
import SelectedBlog from "./components/Blog/BlogDisplay"
import UserRegistration from "./components/User/UserRegistration";
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/blogs" element={<List/>} />
        <Route exact path="/blog" element={<SelectedBlog/>} />
        <Route exact path="/create-user" element={<UserRegistration/>} />
      </Routes>
    </Router>
  );
}

export default App;
