const Router = require('express-promise-router');
const {getAllBlogs, createBlog, updateBlog, getABlog} = require("./blogController")

const routes = () => {
    const router = Router({ mergeParams: true });
    router.route("/allBlogs").get(getAllBlogs);
    router.route("/createBlog").post(createBlog);
    router.route("/updateBlog").post(updateBlog);
    router.route("/getBlog").get(getABlog);
    return router;
};

module.exports = routes;