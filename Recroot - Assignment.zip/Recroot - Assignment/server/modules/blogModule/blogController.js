const blog = require("../../model/blog")
const payloadValidator = require("../../utils/blogSchema")

function generateRandomString() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const length = 10;
    let randomString = '';
    for (let i = 0; i < length; i++) {
        randomString += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return randomString;
}

async function getAllBlogs(req,res){
    try{
        const allBlogs = await blog.find();
        res.status(200).json(allBlogs)
    }catch(err){
        res.status(400).json({ message: err.message });
    }
}

async function createBlog(req, res){
    try{
        const validatePayload = await payloadValidator(req.body)
        if(validatePayload.message){
            res.status(400).send({
                message : validatePayload.message
            })
        }else{
            const randomString = generateRandomString();
            const blogData = req.body
            blogData.blogId = randomString;
            blogData.postedDate = new Date();
            const newBlog = await blog.collection.insertOne(req.body)
            res.status(200).send(newBlog)
        }   
    }catch(err){
        res.status(400).json({ message: err.message });
    }
}

async function updateBlog(req, res){
    try{
        if (!req.body || !req.body.blogId) {
            return res.status(400).send({
                message: "No blog id",
                success: false
            });
        }
        const blogId = req.body.blogId
        const blogExists = await blog.find({blogId : blogId})
        if(blogExists.length == 0){
            return res.status(400).send({
                message: "No blog found for the given Id",
                success: false
            });
        }
        const newData = req.body
        newData.postedDate = new Date();
        const blogUpdation = await blog.collection.updateOne({blogId : blogId}, {$set : newData})
        res.status(200).send(blogUpdation)
    }catch(err){
        res.status(400).json({ message: err.message });
    }
}

async function getABlog(req,res){
    try{
        const allBlogs = await blog.find({blogId : req.query.blogId});
        res.status(200).json(allBlogs)
    }catch(err){
        res.status(400).json({ message: err.message });
    }
}

module.exports = {
    getAllBlogs,createBlog, updateBlog, getABlog
}