const user = require("../../model/user")
const payloadValidator = require("../../utils/userSchema")

async function createUser(req,res){
    try{
        const validatePayload = await payloadValidator(req.body)
        if(validatePayload.message){
            res.status(400).send({
                message : validatePayload.message
            })
        }else{
            const userData = req.body
            userData.userprofilepicture = req.file.path
            const newUser = await user.collection.insertOne(req.body)
            res.status(200).send(newUser)
        }
    }catch(err){
        res.status(400).json({ message: err.message });
    }
}

async function getUser(req,res){
    try{
        if(!req.body && !req.body.email){
            return res.status(400).send({
                message: "No email Id",
                success: false
            });
        }
        const getUser = await user.find({email : req.body.email})
        res.status(200).json({
            data : getUser
        })
    }catch(err){
        res.status(400).json({ message: err.message });
    }
}

module.exports = {
    createUser, getUser
}