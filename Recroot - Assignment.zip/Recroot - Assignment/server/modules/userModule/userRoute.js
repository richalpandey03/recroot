const Router = require('express-promise-router');
const multer = require('multer');
const path = require('path');
const {createUser, getUser} = require("./userController")

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}${path.extname(file.originalname)}`);
    }
  });
const upload = multer({storage: storage});

const routes = () => {
    const router = Router({ mergeParams: true });
    router.route("/createuser").post(upload.single('userimage'), createUser);
    router.route("/getuser").post(getUser);
    return router;
};

module.exports = routes;