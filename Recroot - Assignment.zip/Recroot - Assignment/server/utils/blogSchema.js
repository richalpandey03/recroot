const Joi = require('@hapi/joi');

const schema =Joi.object( {
    blogHeading : Joi.string().required(),
    blogBody : Joi.string().required(),
    author : Joi.string().required(),
    date :Joi.string().required()
})

const payloadValidator = async (data) => {
  try{
  const validationResult = schema.validate(data);
  if (validationResult.error) {
    return validationResult.error
  } else {
    return true;
  }
  }catch(err){
    console.log("err", err)
  }
};

module.exports = payloadValidator;