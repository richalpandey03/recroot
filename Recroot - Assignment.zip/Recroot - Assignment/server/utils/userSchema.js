const Joi = require('@hapi/joi');
const emailpattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,6})+$/;
const allowDomains = "com,net,co,in,org,edu,gov,mil,uk,school".split(",");

const schema =Joi.object( {
    username : Joi.string().required(),
    email : Joi.string().trim().max(100).regex(emailpattern).email({ minDomainSegments: 2, tlds: { allow: allowDomains } }),
    password : Joi.string().required(),
    userimage : Joi.optional()
})

const payloadValidator = async (data) => {
  try{
  const validationResult = schema.validate(data);
  if (validationResult.error) {
    return validationResult.error
  } else {
    return true;
  }
  }catch(err){
    console.log("err", err)
  }
};

module.exports = payloadValidator;