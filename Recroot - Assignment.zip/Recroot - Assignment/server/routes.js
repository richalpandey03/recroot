const express = require("express");
const apiRouter = express.Router();
const blogRoutes = require("./modules/blogModule/blogRoute")
const userRoutes = require("./modules/userModule/userRoute")

module.exports = () =>
	apiRouter
        .use("/blog", blogRoutes())
		.use("/user", userRoutes())
		.get("/healthcheck", (req, res) => {
			res.send("The server is up and running");
		});